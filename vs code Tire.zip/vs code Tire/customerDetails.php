<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Details</title>
    <style>
         @keyframes highlight {
            0% {
                background-color: yellow;
            }
            50% {
                background-color: orange;
            }
            100% {
                background-color: rgb(255, 0, 0);
            }
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        nav {
            background-color: #444;
            padding: 10px 20px;
            text-align:left;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #666;
        }
        
        .highlight-text {
            animation: highlight 3s infinite;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        form {
            margin-top: 20px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 5px;
            width:75%;
            margin-left: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body background="home.jpg">
    <header>
        <h2>Customer Details</h2>
    </header>
    <nav>
        <a href="Wheel Alignment & Tire Works.html">Home page</a>
        <a href="customerdrecall.php">Customer info </a>
      
    </nav>
    <div class="container">
      <div class="content">
    <form action="#" method="GET">
      <label for="customer_name">Customer Name:</label>
      <input type="text" id="customer_name" name="customer_name" required>
      <label for="vehicle_no">Vehicle No:</label>
      <input type="text" id="vehicle_no" name="vehicle_no" required>
      <label for="vehicle_type">Vehicle Type:</label>
      <input type="text" id="vehicle_type" name="vehicle_type" required>
      <label for="address">Address:</label>
      <input type="text" id="address" name="address" required>
      <label for="contact">Contact no:</label>
      <input type="text" id="contact" name="contact" required>
      <label for="date">Date:</label>
      <input type="date" id="date" name="date" required>
      <input type="submit" value="Submit"></div></div>

      <?php
       ini_set('display_errors', 'off');

include 'dbconnection.php';

 
$name = $_GET['customer_name'];
$vno = $_GET['vehicle_no'];
$vty = $_GET['vehicle_type'];
$address = $_GET['address'];
$contact = $_GET['contact'];
$date = $_GET['date'];


if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{

	$sql = "insert into customer_details 
	values ('".$name."','".$vno."','".$vty."','".$address."','".$contact."','".$date."')";
	if ($conn->query($sql) === TRUE) {
		echo "";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
}


?>
  
   
    <footer>
        <p><span class="highlight-text">We provide high-quality tire services and products to keep your vehicle safe on the road.</span></p>
        <p>&copy; 2024 Tire Workshop. All rights reserved.</p>
    </footer>
</body>
</html>

