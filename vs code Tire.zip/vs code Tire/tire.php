<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tire Selection</title>
    <style>
         @keyframes highlight {
            0% {
                background-color: yellow;
            }
            50% {
                background-color: orange;
            }
            100% {
                background-color: rgb(255, 0, 0);
            }
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
            text-align: center;
        }
        .brands {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .brand {
            margin: 10px;
        }
        .brand img {
            width: 150px;
            height: auto;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        .brand img:hover {
            transform: scale(1.05);
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: left;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }

        nav {
            background-color: #444;
            padding: 10px 20px;
            text-align:left;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #666;
        }
        
        .highlight-text {
            animation: highlight 3s infinite;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body background="home.jpg">
    <header>
        <h1>Tire Selection</h1>
    </header>
    <nav>
        <a href="Wheel Alignment & Tire Works.html">Home page</a>
        <a href="tireupdate.php">Stock update</a>
      
    </nav>
    <div class="container">
        <div class="brands">
            <div class="brand">
                <img src="ceat.jpg" alt="Tire Brand 1">
            </div>
            <div class="brand">
                <img src="mrf.png" alt="Tire Brand 2">
            </div>
            <div class="brand">
                <img src="dsi.png" alt="Tire Brand 2">
            </div>
            
        </div>
        <form action="" method="GET">
            <label for="brand">Select Brand:</label>
            <select name="brand" id="brand">
            <option value="">Select Brand</option>
                <option value="ceat">Ceat</option>
                <option value="mrf">MRF</option>
                <option value="dsi">DSI</option>
                
            </select>
            <label for="size" >Select Size:</label>
            <select name="size" id="size">
                <option value="">Select Size</option>
                <option value="18">Size 18</option>
                <option value="20">Size 20</option>
                <option value="22">Size 22</option>
                <option value="24">Size 24</option>
                <option value="26">Size 26</option>
                <option value="28">Size 28</option>
            
            </select>
            <input type="submit" value="Check Availability">
           
            <?php
       ini_set('display_errors', 'off');
include 'dbconnection.php';
$brand=$_GET["brand"];
$size=$_GET["size"];
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	
	echo "";
	$sql = "SELECT * FROM tire where brand='$brand' and size=$size";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Tire count in store:</strong> ". $row["amount"]. "<br>";
    }
} else {
    echo "";
}


$conn->close();
	
}


?>
</form>
<form method= "post" action="">
      <label for="count">Selling tire count</label>
      <input type="text" id="count" name="count" required>

     
        <input type="submit" value="Confirm">
            

      <?php
       //ini_set('display_errors', 'off');
            include 'dbconnection.php';
            $count=$_POST["count"];
            $brand=$_GET["brand"];
            $size=$_GET["size"];


        
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            else{
                
        
            $sql = "UPDATE tire SET amount = amount -$count WHERE brand='$brand' and size=$size";

            if ($conn->query($sql) === TRUE) {
                echo 'Go back to home';
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            //connection closed.
            $conn->close();
            }
        
            ?>
           
</body>
</html>
