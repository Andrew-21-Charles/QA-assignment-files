<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wheel Alignment Booking </title>
    <style>
         @keyframes highlight {
            0% {
                background-color: yellow;
            }
            50% {
                background-color: orange;
            }
            100% {
                background-color: rgb(255, 0, 0);
            }
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        nav {
            background-color: #444;
            padding: 10px 20px;
            text-align:left;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #666;
        }
        
        .highlight-text {
            animation: highlight 3s infinite;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        form {
            margin-top: 20px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 5px;
            width:75%;
            margin-left: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body background="home.jpg">
    <header>
        <h2>Wheel Alignment Booking</h2>
    </header>
    <nav>
        <a href="Wheel Alignment & Tire Works.html">Home page</a>

      
    </nav>
    <div class="container">
      <div class="content">
    <form action="" method="GET">
      <label for="date">Date:</label>
      <input type="date" id="date" name="date" required>
      <input type="submit" value="Submit">

      <?php
       ini_set('display_errors', 'off');

include 'dbconnection.php';

 
$id = $_GET['date'];


if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	//connection confirmed
	echo "Go to home page<br/>";
	$sql = "SELECT * FROM booking where date='$id'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "<br><strong></strong> ". $row["date"]. "<br>";
    
        
    }}
     //8hrs
     $sql = "SELECT * FROM booking where date='$id'and slot='8hrs'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br><strong>Slot 8.00a.m-9.00a.m:</strong> ". $row["vehicleno"]. "<br>";
     }}

    //9hrs
    $sql = "SELECT * FROM booking where date='$id'and slot='9hrs'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Slot 9.00a.m-10.00a.m:</strong> ". $row["vehicleno"]. "<br>";
    }}
 
    //10hrs

    $sql = "SELECT * FROM booking where date='$id'and slot='10hrs'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Slot 10.00a.m-11.00a.m:</strong> ". $row["vehicleno"]. "<br>";
    }}

     //11hrs

     $sql = "SELECT * FROM booking where date='$id'and slot='11hrs'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br><strong>Slot 11.00a.m-12.00p.m:</strong> ". $row["vehicleno"]. "<br>";
     }

      //12hrs

    $sql = "SELECT * FROM booking where date='$id'and slot='12hrs'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Slot 12.00p.m-01.00p.m:</strong> ". $row["vehicleno"]. "<br>";
    }

     //13hrs

     $sql = "SELECT * FROM booking where date='$id'and slot='13hrs'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br><strong>Slot 01.00p.m-02.00p.m:</strong> ". $row["vehicleno"]. "<br>";
     }

      //14hrs

    $sql = "SELECT * FROM booking where date='$id'and slot='14hrs'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Slot 02.00p.m-03.00p.m:</strong> ". $row["vehicleno"]. "<br>";
    }}

     //15hrs

     $sql = "SELECT * FROM booking where date='$id'and slot='15hrs'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br><strong>Slot 03.00p.m-04.00p.m:</strong> ". $row["vehicleno"]. "<br>";
     }}

      //16hrs

    $sql = "SELECT * FROM booking where date='$id'and slot='16hrs'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Slot 04.00p.m-05.00p.m:</strong> ". $row["vehicleno"]. "<br>";
    }}

     //170hrs

     $sql = "SELECT * FROM booking where date='$id'and slot='17hrs'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br><strong>Slot 05.00p.m-06.00p.m:</strong> ". $row["vehicleno"]. "<br>";
         echo "<br><br><br><br><br><br><br><br><br>";
     }}
    }}}

	$conn->close();
}


?>
  </div></div>

  </form>
<form method= "post" action="">
<label for="slot" >Select a time which not mentioned above:</label>
            <select name="slot" id="slot">
                <option value="">Select a slot</option>
                <option value="8hrs">08.00a.m-09.00a.m</option>
                <option value="9hrs">09.00a.m-10.00a.m</option>
                <option value="10hrs">10.00a.m-11.00a.m</option>
                <option value="11hrs">11.00a.m-12.00p.m</option>
                <option value="12hrs">12.00p.m-01.00p.m</option>
                <option value="13hrs">01.00p.m-02.00p.m</option>
                <option value="14hrs">02.00p.m-03.00p.m</option>
                <option value="15hrs">03.00p.m-04.00p.m</option>
                <option value="16hrs">04.00p.m-05.00p.m</option>
                <option value="17hrs">05.00p.m-06.00p.m</option>
              </select>
              <label for="vehicleno">Vehicle No:</label>
      <input type="text" id="vehicleno" name="vehicleno" required>

            <input type="submit" value="Confirm">

      <?php
       //ini_set('display_errors', 'off');
            include 'dbconnection.php';
            $slot=$_POST["slot"];
            $id = $_GET['date'];
            $vehicleno=$_POST["vehicleno"];


        
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            else{
            
                $sql = "insert into booking 
                values ('".$id."','".$slot."','".$vehicleno."')";
                if ($conn->query($sql) === TRUE) {
                    echo "New record created successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            
                $conn->close();
            }
        
            ?>
   
   
</body>
</html>
