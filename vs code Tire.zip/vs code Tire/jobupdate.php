<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JOB Update</title>
    <style>
         @keyframes highlight {
            0% {
                background-color: yellow;
            }
            50% {
                background-color: orange;
            }
            100% {
                background-color: rgb(255, 0, 0);
            }
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        nav {
            background-color: #444;
            padding: 10px 20px;
            text-align:left;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #666;
        }
        
        .highlight-text {
            animation: highlight 3s infinite;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        form {
            margin-top: 20px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 5px;
            width:75%;
            margin-left: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body background="home.jpg">
    <header>
        <h2>JOB Update</h2>
    </header>
    <nav>
        <a href="Wheel Alignment & Tire Works.html">Home page</a>
        <a href="jobtracking.php">Job Tracker</a>
      
    </nav>
    <div class="container">
      <div class="content">
    <form action="" method="GET">
    <label for="job_no">Receipt Number:</label>
            <input type="text" id="job_no" name="job_no" required>
            
            <label for="job_status">Order Status:</label>
            <select id="job_status" name="job_status" required>
                <option value="">Select JOB Status</option>
                <option value=" In que">IN QUE</option>
                <option value="Next in que">NEXT IN QUE</option>
                <option value="Jacked">Jacked</option>
                <option value="Work in progress">WORK IN PROGRESS</option>
                <option value="incomplete">INCOMPLETE</option>
                <option value="Complete">COMPLETE</option>
            </select>  
            <input type="submit" value="Job Update"><br><br>

            <?php
            ini_set('display_errors', 'off');
include 'dbconnection.php';

 
$rno = $_GET['job_no'];
$ost = $_GET['job_status'];



if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{

	

    $sql = "DELETE FROM job WHERE job_no=$rno";
	

if ($conn->query($sql) === TRUE) {
  echo "Go to home page";
} else {
  echo "Error deleting record: " . $conn->error;
}

	$sql = "insert into job   
    values ('".$rno."','".$ost."')";

	if ($conn->query($sql) === TRUE) {

	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
}


?>
  </div></div>
   
    <footer>
        <p><span class="highlight-text">We provide high-quality tire services and products to keep your vehicle safe on the road.</span></p>
        <p>&copy; 2024 Tire Workshop. All rights reserved.</p>
    </footer>
</body>
</html>
