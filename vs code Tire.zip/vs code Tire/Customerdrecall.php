<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer info</title>
    <style>
         @keyframes highlight {
            0% {
                background-color: yellow;
            }
            50% {
                background-color: orange;
            }
            100% {
                background-color: rgb(255, 0, 0);
            }
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        nav {
            background-color: #444;
            padding: 10px 20px;
            text-align:left;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #666;
        }
        
        .highlight-text {
            animation: highlight 3s infinite;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        form {
            margin-top: 20px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 5px;
            width:75%;
            margin-left: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        form input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body background="home.jpg">
    <header>
        <h2>Customer Information</h2>
    </header>
    <nav>
        <a href="Wheel Alignment & Tire Works.html">Home page</a>
        <a href="customerDetails.php">Customer Details </a>
      
    </nav>
    <div class="container">
      <div class="content">
    <form action="" method="GET">
      <label for="vehicleno">Vehicle no</label>
      <input type="text" id="vehicleno" name="vehicleno" required>
      <input type="submit" value="Submit">

      <?php
       ini_set('display_errors', 'off');
include 'dbconnection.php';

$id = $_GET['vehicleno'];

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	
	echo "";
	$sql = "SELECT * FROM  customer_details where Vehicleno='$id' ";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "<br><br><br><strong>Vehicle no:</strong> ". $row["Vehicleno"]. "<br>";
        echo "<br><strong>Customer name:</strong> ". $row["Name"]. "<br>";
        echo "<br><strong>Customer address:</strong> ". $row["Address"]. "<br>";
        echo "<br><strong>Contact number:</strong> ". $row["contact"]. "<br>";
    }
} else {
    echo "";
}


$conn->close();
	
}


?>
  </div></div>
   
    <footer>
        <p><span class="highlight-text">We provide high-quality tire services and products to keep your vehicle safe on the road.</span></p>
        <p>&copy; 2024 Tire Workshop. All rights reserved.</p>
    </footer>
</body>
</html>
